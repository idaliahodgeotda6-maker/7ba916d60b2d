// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Solve NLP with IPOPT\n", stdout);
  return lionss_run_workload("SolverIpopt");
}
