// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Spread reedmace\n", stdout);
  return lionss_run_workload("reedmace");
}
