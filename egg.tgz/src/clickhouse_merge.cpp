// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Merge data parts\n", stdout);
  return lionss_run_workload("clickhouse_merge");
}
