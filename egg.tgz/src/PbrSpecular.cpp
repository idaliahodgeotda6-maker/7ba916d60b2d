// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Evaluate specular BRDF"); }
int main(){
  announce();
  return lionss_run_workload("PbrSpecular");
}
