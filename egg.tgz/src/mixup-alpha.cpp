// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Apply mixup"); }
int main(){
  announce();
  return lionss_run_workload("mixup-alpha");
}
