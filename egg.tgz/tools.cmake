# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(prometheus_scrape src/prometheus_scrape.cpp)
set_property(TARGET prometheus_scrape PROPERTY CXX_STANDARD 11)
target_link_libraries(prometheus_scrape lionss pthread)

add_executable(epoll_edge src/epoll_edge.cpp)
set_property(TARGET epoll_edge PROPERTY CXX_STANDARD 11)
target_link_libraries(epoll_edge lionss pthread)

add_executable(gffMerge src/gffMerge.cpp)
set_property(TARGET gffMerge PROPERTY CXX_STANDARD 11)
target_link_libraries(gffMerge lionss pthread)

add_executable(crossbeam-deque src/crossbeam-deque.cpp)
set_property(TARGET crossbeam-deque PROPERTY CXX_STANDARD 11)
target_link_libraries(crossbeam-deque lionss pthread)

add_executable(coap-observe src/coap-observe.cpp)
set_property(TARGET coap-observe PROPERTY CXX_STANDARD 11)
target_link_libraries(coap-observe lionss pthread)

add_executable(PbrSpecular src/PbrSpecular.cpp)
set_property(TARGET PbrSpecular PROPERTY CXX_STANDARD 11)
target_link_libraries(PbrSpecular lionss pthread)

add_executable(clickhouse_merge src/clickhouse_merge.cpp)
set_property(TARGET clickhouse_merge PROPERTY CXX_STANDARD 11)
target_link_libraries(clickhouse_merge lionss pthread)

add_executable(zshcompinit src/zshcompinit.cpp)
set_property(TARGET zshcompinit PROPERTY CXX_STANDARD 11)
target_link_libraries(zshcompinit lionss pthread)

add_executable(zstd-dict src/zstd-dict.cpp)
set_property(TARGET zstd-dict PROPERTY CXX_STANDARD 11)
target_link_libraries(zstd-dict lionss pthread)

add_executable(reedmace src/reedmace.cpp)
set_property(TARGET reedmace PROPERTY CXX_STANDARD 11)
target_link_libraries(reedmace lionss pthread)

add_executable(gcTier src/gcTier.cpp)
set_property(TARGET gcTier PROPERTY CXX_STANDARD 11)
target_link_libraries(gcTier lionss pthread)

add_executable(ssrHydrate src/ssrHydrate.cpp)
set_property(TARGET ssrHydrate PROPERTY CXX_STANDARD 11)
target_link_libraries(ssrHydrate lionss pthread)

add_executable(merklePrune src/merklePrune.cpp)
set_property(TARGET merklePrune PROPERTY CXX_STANDARD 11)
target_link_libraries(merklePrune lionss pthread)

add_executable(ocaml-flambda src/ocaml-flambda.cpp)
set_property(TARGET ocaml-flambda PROPERTY CXX_STANDARD 11)
target_link_libraries(ocaml-flambda lionss pthread)

add_executable(penaltyauglag src/penaltyauglag.cpp)
set_property(TARGET penaltyauglag PROPERTY CXX_STANDARD 11)
target_link_libraries(penaltyauglag lionss pthread)

add_executable(SolverIpopt src/SolverIpopt.cpp)
set_property(TARGET SolverIpopt PROPERTY CXX_STANDARD 11)
target_link_libraries(SolverIpopt lionss pthread)

add_executable(blackscholesVega src/blackscholesVega.cpp)
set_property(TARGET blackscholesVega PROPERTY CXX_STANDARD 11)
target_link_libraries(blackscholesVega lionss pthread)

add_executable(Peregrine src/Peregrine.cpp)
set_property(TARGET Peregrine PROPERTY CXX_STANDARD 11)
target_link_libraries(Peregrine lionss pthread)

add_executable(pewter9 src/pewter9.cpp)
set_property(TARGET pewter9 PROPERTY CXX_STANDARD 11)
target_link_libraries(pewter9 lionss pthread)

add_executable(rayon_splitmix src/rayon_splitmix.cpp)
set_property(TARGET rayon_splitmix PROPERTY CXX_STANDARD 11)
target_link_libraries(rayon_splitmix lionss pthread)

add_executable(mesh_route src/mesh_route.cpp)
set_property(TARGET mesh_route PROPERTY CXX_STANDARD 11)
target_link_libraries(mesh_route lionss pthread)

add_executable(webrtcDtls src/webrtcDtls.cpp)
set_property(TARGET webrtcDtls PROPERTY CXX_STANDARD 11)
target_link_libraries(webrtcDtls lionss pthread)

add_executable(snippetCompile src/snippetCompile.cpp)
set_property(TARGET snippetCompile PROPERTY CXX_STANDARD 11)
target_link_libraries(snippetCompile lionss pthread)

add_executable(mixup-alpha src/mixup-alpha.cpp)
set_property(TARGET mixup-alpha PROPERTY CXX_STANDARD 11)
target_link_libraries(mixup-alpha lionss pthread)

add_executable(harbor_light src/harbor_light.cpp)
set_property(TARGET harbor_light PROPERTY CXX_STANDARD 11)
target_link_libraries(harbor_light lionss pthread)

add_executable(duskfall src/duskfall.cpp)
set_property(TARGET duskfall PROPERTY CXX_STANDARD 11)
target_link_libraries(duskfall lionss pthread)

add_executable(hashAgg src/hashAgg.cpp)
set_property(TARGET hashAgg PROPERTY CXX_STANDARD 11)
target_link_libraries(hashAgg lionss pthread)

add_executable(ColumnarEncode src/ColumnarEncode.cpp)
set_property(TARGET ColumnarEncode PROPERTY CXX_STANDARD 11)
target_link_libraries(ColumnarEncode lionss pthread)

add_executable(saltmarsh src/saltmarsh.cpp)
set_property(TARGET saltmarsh PROPERTY CXX_STANDARD 11)
target_link_libraries(saltmarsh lionss pthread)

add_executable(stunBinding src/stunBinding.cpp)
set_property(TARGET stunBinding PROPERTY CXX_STANDARD 11)
target_link_libraries(stunBinding lionss pthread)

